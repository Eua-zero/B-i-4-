﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaitapB4
{
    public partial class ListView : Form
    {
        public ListView()
        {
            InitializeComponent();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {            
            frmNhânViên form = new frmNhânViên();
            if (form.ShowDialog() == DialogResult.OK)
            {
                dgvListView.Rows.Add(form.MSNV, form.Ten, form.Luong);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvListView.CurrentRow != null && dgvListView.CurrentRow.Index >= 0)
            {
                int rowIndex = dgvListView.CurrentRow.Index;
                string MSNV = dgvListView.Rows[rowIndex].Cells[0].Value != null
             ? dgvListView.Rows[rowIndex].Cells[0].Value.ToString()
             : string.Empty;

                string Ten = dgvListView.Rows[rowIndex].Cells[1].Value != null
                    ? dgvListView.Rows[rowIndex].Cells[1].Value.ToString()
                    : string.Empty;

                string Luong = dgvListView.Rows[rowIndex].Cells[2].Value != null
                    ? dgvListView.Rows[rowIndex].Cells[2].Value.ToString()
                    : string.Empty;

                frmNhânViên form = new frmNhânViên(MSNV, Ten, Luong);
                if (form.ShowDialog() == DialogResult.OK)
                {
                    dgvListView.Rows[rowIndex].Cells[0].Value = form.MSNV;
                    dgvListView.Rows[rowIndex].Cells[1].Value = form.Ten;
                    dgvListView.Rows[rowIndex].Cells[2].Value = form.Luong;
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một hàng để chỉnh sửa.", "Thông báo");
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvListView.CurrentRow != null)
            {
                dgvListView.Rows.Remove(dgvListView.CurrentRow);
                                    
            }
        }

private void btnClose_Click(object sender, EventArgs e)
        {
            if (dgvListView.CurrentRow != null)
            {
                this.Close();
            }
        }
    }
}
