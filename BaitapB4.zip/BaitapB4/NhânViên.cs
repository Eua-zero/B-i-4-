﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace BaitapB4
{
    public partial class frmNhânViên : Form
    {
        public frmNhânViên()
        {
            InitializeComponent();
        }
        public string MSNV { get; set; }
        public string Ten { get; set; }
        public string Luong { get; set; }
        public frmNhânViên(string MSNV = "", string Ten = "", string Luong = "")
        {
            InitializeComponent();
            txtMSNV.Text = MSNV;
            txtTen.Text = Ten;
            txtLuong.Text = Luong;
        }

        private void btnDongy_Click(object sender, EventArgs e)
        {
            MSNV = txtMSNV.Text;
            Ten = txtTen.Text;
            Luong = txtLuong.Text;
            DialogResult = DialogResult.OK;
        }

        private void btnboqua_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
